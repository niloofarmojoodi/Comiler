package LULU;

public class SymbolTableTree {
    private Scope root;
    private Scope currentScope;

    public SymbolTableTree(){
        this.root = new Scope("Main" , 0);
        this.currentScope = root;

    }

    public void setCurrentScope(Scope currentScope) {
        this.currentScope = currentScope;
    }

    public Scope getCurrentScope() {
        return currentScope;
    }

    public void setRoot(Scope root) {
        this.root = root;
    }
    public Scope getRoot() {
        return root;
    }

    public void addToTree(String name, int line)
    {
        Scope newScope = new Scope(name, line);
        currentScope.addChildren(newScope);
        setCurrentScope(newScope);
    }

    public void exitScope(){
        currentScope = currentScope.getParent();
    }
}
