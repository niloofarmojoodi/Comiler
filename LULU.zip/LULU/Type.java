package LULU;

public class Type {
    public String tp_name;

    public Type(String name){
        this.tp_name = name;
    }


    boolean check_convert (String tSource,String tTarget )
    {
        if(tSource== "int"){
            if (tTarget == "string" || tTarget == "float" || tTarget == "bool")
                return true;
            else
                return false;
        }
        else if(tSource== "bool"){
            if (tTarget == "int")
                return true;
            else
                return false;
        }
        else
        {
            if (tTarget == "int")
                return true;
            else
                return false;
        }

    }
    boolean is_expr_boolean (String expr1, String op ,String expr2 ){

    }
}
