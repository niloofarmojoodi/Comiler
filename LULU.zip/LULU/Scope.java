package LULU;
import java.util.ArrayList;
import LULU.SymbolTableTot;

public class Scope {

    private String Name;
    private int id ;
    private Scope Parent;
    private ArrayList<Scope> Children;
    private SymbolTableTot Table;
    private int width;


    //just for root





    public Scope(String name , int id)
    {
        this.Children = new ArrayList<>();
        this.Table = new SymbolTableTot();
        this.Name = name;
        this.id=id;
    }

    public Scope insert_child(String name , int id){
        Scope child = new Scope(name , id);
        child.setParent(this);
        getChildren().add(child);
        return child;
    }

    public int calcWidth() {
        int width = 0;
        if(this.Children.size() == 0)
        {
            width = this.Table.calc_width();
        }
        else
        {
            for(int i=0;i<this.Children.size();i++){
                width += this.Children.get(i).calcWidth();
            }
            width += this.Table.calc_width();
        }

        return width;

    }

    public void setTable(SymbolTableTot table) {
        Table = table;
    }

    public void setParent(Scope parent) {
        Parent = parent;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setId(int id) {
        this.id = id;
    }



    public void addChildren(Scope child) {
        Children.add(child);
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public String getName() {
        return Name;
    }

    public int getId() {
        return id;
    }



    public Scope getParent() {
        return Parent;
    }

    public SymbolTableTot getTable() {
        return Table;
    }

    public int getWidth() {
        return width;
    }

    public ArrayList<Scope> getChildren() {
        return Children;
    }

}
