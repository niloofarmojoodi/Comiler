package LULU;
public enum Access
{
    PRIVATE , PUBLIC , PROTECTED;
}