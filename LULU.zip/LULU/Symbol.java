package LULU;

import java.util.*;
enum AccessModifier{
    Private , Protected , Public;
}

public abstract class Symbol {
    private  AccessModifier accessModifier;
    public AccessModifier getAccessModifier()
    {
        return accessModifier;
    }
    private String Name;
    private int Size;
    // private Type type;
    private boolean Const;
    private int Offset;




}