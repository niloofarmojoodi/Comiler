package LULU;
import java.util.Stack;;
import LULU.Symbol_Table;
public class MyStack extends Stack{

    public MyStack()
    {
        Symbol_Table ST = new Symbol_Table();

    }
}
