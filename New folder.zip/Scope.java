package LULU;
import java.util.Stack;
import LULU.Symbol_Table;
public Stack<Symbol_Table> s = new Stack<Symbol_Table>();
public class Scope {

    public Scope()
    {

        s.push()
    }
   private int id;
}
