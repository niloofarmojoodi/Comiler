package LULU;
import LULU.Type;
public class Symbol_Table {
    private String Name;
    private Type tp =new Type() ;
    private Object value;
    private int width;
    private String enviorment;

    public String tp_val = this.value.getClass().getName();

    public void setWidth(int w){
        if(tp.check_convert(this.tp_val, tp.getTp_name())){
            if(tp.getTp_name() == "int"){
                w = 4;
            }
            if(tp.getTp_name() == "bool"){
                w=1;
            }
            if(tp.getTp_name() == "string" ){
                int l = this.value.toString().length();
                w = 2*l + 2;
            }
        }
        //Array checking

    }




}
