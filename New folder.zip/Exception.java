package LULU;

public class Exception {
}
