package LULU;

public class Type {
    private String tp_name;
    public String getTp_name() {
        return tp_name;
    }

    public void setTp_name(String tp_name) {
        this.tp_name = tp_name;
    }


    boolean check_convert (String tSource,String tTarget )
    {
        if(tSource== "int"){
            if (tTarget == "string" || tTarget == "float" || tTarget == "bool")
                return true;
            else
                return false;
        }
        else if(tSource== "bool"){
            if (tTarget == "int")
                return true;
            else
                return false;
        }
        else
        {
            if (tTarget == "int")
                return true;
            else
                return false;
        }

    }
}
