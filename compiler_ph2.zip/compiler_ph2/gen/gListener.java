// Generated from C:/Users/Niloofar Mojoodi/IdeaProjects/compiler_ph2/src\g.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link gParser}.
 */
public interface gListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link gParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(gParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(gParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#ft_dcl}.
	 * @param ctx the parse tree
	 */
	void enterFt_dcl(gParser.Ft_dclContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#ft_dcl}.
	 * @param ctx the parse tree
	 */
	void exitFt_dcl(gParser.Ft_dclContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#func_dcl}.
	 * @param ctx the parse tree
	 */
	void enterFunc_dcl(gParser.Func_dclContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#func_dcl}.
	 * @param ctx the parse tree
	 */
	void exitFunc_dcl(gParser.Func_dclContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#args}.
	 * @param ctx the parse tree
	 */
	void enterArgs(gParser.ArgsContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#args}.
	 * @param ctx the parse tree
	 */
	void exitArgs(gParser.ArgsContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#args_var}.
	 * @param ctx the parse tree
	 */
	void enterArgs_var(gParser.Args_varContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#args_var}.
	 * @param ctx the parse tree
	 */
	void exitArgs_var(gParser.Args_varContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#type_dcl}.
	 * @param ctx the parse tree
	 */
	void enterType_dcl(gParser.Type_dclContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#type_dcl}.
	 * @param ctx the parse tree
	 */
	void exitType_dcl(gParser.Type_dclContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#var_def}.
	 * @param ctx the parse tree
	 */
	void enterVar_def(gParser.Var_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#var_def}.
	 * @param ctx the parse tree
	 */
	void exitVar_def(gParser.Var_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#var_val}.
	 * @param ctx the parse tree
	 */
	void enterVar_val(gParser.Var_valContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#var_val}.
	 * @param ctx the parse tree
	 */
	void exitVar_val(gParser.Var_valContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#ft_def}.
	 * @param ctx the parse tree
	 */
	void enterFt_def(gParser.Ft_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#ft_def}.
	 * @param ctx the parse tree
	 */
	void exitFt_def(gParser.Ft_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#type_def}.
	 * @param ctx the parse tree
	 */
	void enterType_def(gParser.Type_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#type_def}.
	 * @param ctx the parse tree
	 */
	void exitType_def(gParser.Type_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#component}.
	 * @param ctx the parse tree
	 */
	void enterComponent(gParser.ComponentContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#component}.
	 * @param ctx the parse tree
	 */
	void exitComponent(gParser.ComponentContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#access_modifier}.
	 * @param ctx the parse tree
	 */
	void enterAccess_modifier(gParser.Access_modifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#access_modifier}.
	 * @param ctx the parse tree
	 */
	void exitAccess_modifier(gParser.Access_modifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#fun_def}.
	 * @param ctx the parse tree
	 */
	void enterFun_def(gParser.Fun_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#fun_def}.
	 * @param ctx the parse tree
	 */
	void exitFun_def(gParser.Fun_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(gParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(gParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code assignment}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(gParser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code assignment}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(gParser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code function_call}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterFunction_call(gParser.Function_callContext ctx);
	/**
	 * Exit a parse tree produced by the {@code function_call}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitFunction_call(gParser.Function_callContext ctx);
	/**
	 * Enter a parse tree produced by the {@code conditional_statement}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterConditional_statement(gParser.Conditional_statementContext ctx);
	/**
	 * Exit a parse tree produced by the {@code conditional_statement}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitConditional_statement(gParser.Conditional_statementContext ctx);
	/**
	 * Enter a parse tree produced by the {@code loop_statement}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterLoop_statement(gParser.Loop_statementContext ctx);
	/**
	 * Exit a parse tree produced by the {@code loop_statement}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitLoop_statement(gParser.Loop_statementContext ctx);
	/**
	 * Enter a parse tree produced by the {@code break}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterBreak(gParser.BreakContext ctx);
	/**
	 * Exit a parse tree produced by the {@code break}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitBreak(gParser.BreakContext ctx);
	/**
	 * Enter a parse tree produced by the {@code continue}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterContinue(gParser.ContinueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code continue}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitContinue(gParser.ContinueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code destruction}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterDestruction(gParser.DestructionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code destruction}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitDestruction(gParser.DestructionContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterAssign(gParser.AssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitAssign(gParser.AssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#var}.
	 * @param ctx the parse tree
	 */
	void enterVar(gParser.VarContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#var}.
	 * @param ctx the parse tree
	 */
	void exitVar(gParser.VarContext ctx);
	/**
	 * Enter a parse tree produced by the {@code reef}
	 * labeled alternative in {@link gParser#ref}.
	 * @param ctx the parse tree
	 */
	void enterReef(gParser.ReefContext ctx);
	/**
	 * Exit a parse tree produced by the {@code reef}
	 * labeled alternative in {@link gParser#ref}.
	 * @param ctx the parse tree
	 */
	void exitReef(gParser.ReefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code varLabel}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVarLabel(gParser.VarLabelContext ctx);
	/**
	 * Exit a parse tree produced by the {@code varLabel}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVarLabel(gParser.VarLabelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opBitwise}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpBitwise(gParser.OpBitwiseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opBitwise}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpBitwise(gParser.OpBitwiseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code listLabel}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterListLabel(gParser.ListLabelContext ctx);
	/**
	 * Exit a parse tree produced by the {@code listLabel}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitListLabel(gParser.ListLabelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opLogical}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpLogical(gParser.OpLogicalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opLogical}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpLogical(gParser.OpLogicalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code handleCall}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterHandleCall(gParser.HandleCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code handleCall}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitHandleCall(gParser.HandleCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOp(gParser.UnaryOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOp(gParser.UnaryOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code paranthese}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterParanthese(gParser.ParantheseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code paranthese}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitParanthese(gParser.ParantheseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opFour}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpFour(gParser.OpFourContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opFour}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpFour(gParser.OpFourContext ctx);
	/**
	 * Enter a parse tree produced by the {@code nilLabel}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNilLabel(gParser.NilLabelContext ctx);
	/**
	 * Exit a parse tree produced by the {@code nilLabel}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNilLabel(gParser.NilLabelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opOne}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpOne(gParser.OpOneContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opOne}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpOne(gParser.OpOneContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arrayVal}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArrayVal(gParser.ArrayValContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arrayVal}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArrayVal(gParser.ArrayValContext ctx);
	/**
	 * Enter a parse tree produced by the {@code funcCall}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFuncCall(gParser.FuncCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code funcCall}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFuncCall(gParser.FuncCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opTwo}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpTwo(gParser.OpTwoContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opTwo}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpTwo(gParser.OpTwoContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opThree}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpThree(gParser.OpThreeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opThree}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpThree(gParser.OpThreeContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#func_call}.
	 * @param ctx the parse tree
	 */
	void enterFunc_call(gParser.Func_callContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#func_call}.
	 * @param ctx the parse tree
	 */
	void exitFunc_call(gParser.Func_callContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#list}.
	 * @param ctx the parse tree
	 */
	void enterList(gParser.ListContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#list}.
	 * @param ctx the parse tree
	 */
	void exitList(gParser.ListContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#handle_call}.
	 * @param ctx the parse tree
	 */
	void enterHandle_call(gParser.Handle_callContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#handle_call}.
	 * @param ctx the parse tree
	 */
	void exitHandle_call(gParser.Handle_callContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#params}.
	 * @param ctx the parse tree
	 */
	void enterParams(gParser.ParamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#params}.
	 * @param ctx the parse tree
	 */
	void exitParams(gParser.ParamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#cond_stmt}.
	 * @param ctx the parse tree
	 */
	void enterCond_stmt(gParser.Cond_stmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#cond_stmt}.
	 * @param ctx the parse tree
	 */
	void exitCond_stmt(gParser.Cond_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#switch_body}.
	 * @param ctx the parse tree
	 */
	void enterSwitch_body(gParser.Switch_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#switch_body}.
	 * @param ctx the parse tree
	 */
	void exitSwitch_body(gParser.Switch_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#loop_stmt}.
	 * @param ctx the parse tree
	 */
	void enterLoop_stmt(gParser.Loop_stmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#loop_stmt}.
	 * @param ctx the parse tree
	 */
	void exitLoop_stmt(gParser.Loop_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(gParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(gParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#const_val}.
	 * @param ctx the parse tree
	 */
	void enterConst_val(gParser.Const_valContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#const_val}.
	 * @param ctx the parse tree
	 */
	void exitConst_val(gParser.Const_valContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#unary_op}.
	 * @param ctx the parse tree
	 */
	void enterUnary_op(gParser.Unary_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#unary_op}.
	 * @param ctx the parse tree
	 */
	void exitUnary_op(gParser.Unary_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#op1}.
	 * @param ctx the parse tree
	 */
	void enterOp1(gParser.Op1Context ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#op1}.
	 * @param ctx the parse tree
	 */
	void exitOp1(gParser.Op1Context ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#op2}.
	 * @param ctx the parse tree
	 */
	void enterOp2(gParser.Op2Context ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#op2}.
	 * @param ctx the parse tree
	 */
	void exitOp2(gParser.Op2Context ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#op3}.
	 * @param ctx the parse tree
	 */
	void enterOp3(gParser.Op3Context ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#op3}.
	 * @param ctx the parse tree
	 */
	void exitOp3(gParser.Op3Context ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#op4}.
	 * @param ctx the parse tree
	 */
	void enterOp4(gParser.Op4Context ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#op4}.
	 * @param ctx the parse tree
	 */
	void exitOp4(gParser.Op4Context ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#bitwise}.
	 * @param ctx the parse tree
	 */
	void enterBitwise(gParser.BitwiseContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#bitwise}.
	 * @param ctx the parse tree
	 */
	void exitBitwise(gParser.BitwiseContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#logical}.
	 * @param ctx the parse tree
	 */
	void enterLogical(gParser.LogicalContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#logical}.
	 * @param ctx the parse tree
	 */
	void exitLogical(gParser.LogicalContext ctx);
}