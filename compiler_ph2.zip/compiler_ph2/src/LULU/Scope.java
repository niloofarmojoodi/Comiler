package LULU;
import java.util.LinkedList;

public class Scope {
    private String Name;
    private LinkedList<Symbol_tot> Data;
    private Scope Parent;
    private LinkedList<Scope> Children = new LinkedList<>();;
   // private int width;

    public Scope(String Name,LinkedList data , Scope parent){
        this.Name = Name;
        this.Data = data;
        this.Parent = parent;
    }

    public void setChildren(LinkedList<Scope> children) {
        Children = children;
    }

    public void setParent(Scope parent) {
        Parent = parent;
    }

    public LinkedList<Symbol_tot> getData() {
        return Data;
    }

    public Scope getParent() {
        return Parent;
    }

    public LinkedList<Scope> getChildren() {
        return Children;
    }

    public Scope insert_child(String name ,LinkedList data ){
        Scope child = new Scope(name ,data, this);
        this.Children.addLast(child);
        return child;
    }

   /* public int calcWidth() {
        int width = 0;
        if(this.Children.size() == 0)
        {
            width = this.Table.calc_width();
        }
        else
        {
            for(int i=0;i<this.Children.size();i++){
                width += this.Children.get(i).calcWidth();
            }
            width += this.Table.calc_width();
        }

        return width;

    }*/



}
