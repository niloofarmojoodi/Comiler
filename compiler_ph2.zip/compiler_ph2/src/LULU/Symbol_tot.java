package lulu;

public class Symbol_tot  {
    private  int width;
    private  int offset;
    private Type type;
    private String name;
    private Access acces;

    public void setWidth(int width) {
        this.width = width;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public void setAcces(Access acces) {
        this.acces = acces;
    }

    public int getWidth() {
        return width;
    }

    public String getName() {
        return name;
    }

    public int getOffset() {
        return offset;
    }

    public Type getType() {
        return type;
    }

    public Access getAcces() {
        return acces;
    }
}
