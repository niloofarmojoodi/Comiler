package lulu;// Generated from C:/Users/Mohammad Hossein/IdeaProjects/compiler_project\g.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link gParser}.
 */
public interface gListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link gParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(gParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(gParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#test}.
	 * @param ctx the parse tree
	 */
	void enterTest(gParser.TestContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#test}.
	 * @param ctx the parse tree
	 */
	void exitTest(gParser.TestContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#ft_dcl}.
	 * @param ctx the parse tree
	 */
	void enterFt_dcl(gParser.Ft_dclContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#ft_dcl}.
	 * @param ctx the parse tree
	 */
	void exitFt_dcl(gParser.Ft_dclContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#func_dcl}.
	 * @param ctx the parse tree
	 */
	void enterFunc_dcl(gParser.Func_dclContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#func_dcl}.
	 * @param ctx the parse tree
	 */
	void exitFunc_dcl(gParser.Func_dclContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#args}.
	 * @param ctx the parse tree
	 */
	void enterArgs(gParser.ArgsContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#args}.
	 * @param ctx the parse tree
	 */
	void exitArgs(gParser.ArgsContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#args_var}.
	 * @param ctx the parse tree
	 */
	void enterArgs_var(gParser.Args_varContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#args_var}.
	 * @param ctx the parse tree
	 */
	void exitArgs_var(gParser.Args_varContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#type_dcl}.
	 * @param ctx the parse tree
	 */
	void enterType_dcl(gParser.Type_dclContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#type_dcl}.
	 * @param ctx the parse tree
	 */
	void exitType_dcl(gParser.Type_dclContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#var_def}.
	 * @param ctx the parse tree
	 */
	void enterVar_def(gParser.Var_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#var_def}.
	 * @param ctx the parse tree
	 */
	void exitVar_def(gParser.Var_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#var_val}.
	 * @param ctx the parse tree
	 */
	void enterVar_val(gParser.Var_valContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#var_val}.
	 * @param ctx the parse tree
	 */
	void exitVar_val(gParser.Var_valContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#ft_def}.
	 * @param ctx the parse tree
	 */
	void enterFt_def(gParser.Ft_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#ft_def}.
	 * @param ctx the parse tree
	 */
	void exitFt_def(gParser.Ft_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#type_def}.
	 * @param ctx the parse tree
	 */
	void enterType_def(gParser.Type_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#type_def}.
	 * @param ctx the parse tree
	 */
	void exitType_def(gParser.Type_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#component}.
	 * @param ctx the parse tree
	 */
	void enterComponent(gParser.ComponentContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#component}.
	 * @param ctx the parse tree
	 */
	void exitComponent(gParser.ComponentContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#access_modifier}.
	 * @param ctx the parse tree
	 */
	void enterAccess_modifier(gParser.Access_modifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#access_modifier}.
	 * @param ctx the parse tree
	 */
	void exitAccess_modifier(gParser.Access_modifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#fun_def}.
	 * @param ctx the parse tree
	 */
	void enterFun_def(gParser.Fun_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#fun_def}.
	 * @param ctx the parse tree
	 */
	void exitFun_def(gParser.Fun_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(gParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(gParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code assignstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterAssignstmt(gParser.AssignstmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code assignstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitAssignstmt(gParser.AssignstmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code funcCallstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterFuncCallstmt(gParser.FuncCallstmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code funcCallstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitFuncCallstmt(gParser.FuncCallstmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code condstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterCondstmt(gParser.CondstmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code condstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitCondstmt(gParser.CondstmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code loopstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterLoopstmt(gParser.LoopstmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code loopstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitLoopstmt(gParser.LoopstmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code breakstmr}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterBreakstmr(gParser.BreakstmrContext ctx);
	/**
	 * Exit a parse tree produced by the {@code breakstmr}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitBreakstmr(gParser.BreakstmrContext ctx);
	/**
	 * Enter a parse tree produced by the {@code continuestmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterContinuestmt(gParser.ContinuestmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code continuestmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitContinuestmt(gParser.ContinuestmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code destructstmr}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterDestructstmr(gParser.DestructstmrContext ctx);
	/**
	 * Exit a parse tree produced by the {@code destructstmr}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitDestructstmr(gParser.DestructstmrContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterAssign(gParser.AssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitAssign(gParser.AssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#var}.
	 * @param ctx the parse tree
	 */
	void enterVar(gParser.VarContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#var}.
	 * @param ctx the parse tree
	 */
	void exitVar(gParser.VarContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#ref}.
	 * @param ctx the parse tree
	 */
	void enterRef(gParser.RefContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#ref}.
	 * @param ctx the parse tree
	 */
	void exitRef(gParser.RefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code binaryOp1Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBinaryOp1Expr(gParser.BinaryOp1ExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code binaryOp1Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBinaryOp1Expr(gParser.BinaryOp1ExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code allocHandleCallExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAllocHandleCallExpr(gParser.AllocHandleCallExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code allocHandleCallExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAllocHandleCallExpr(gParser.AllocHandleCallExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code binaryOp3Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBinaryOp3Expr(gParser.BinaryOp3ExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code binaryOp3Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBinaryOp3Expr(gParser.BinaryOp3ExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code logicalExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLogicalExpr(gParser.LogicalExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code logicalExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLogicalExpr(gParser.LogicalExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code nestedExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNestedExpr(gParser.NestedExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code nestedExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNestedExpr(gParser.NestedExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code binaryOp4Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBinaryOp4Expr(gParser.BinaryOp4ExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code binaryOp4Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBinaryOp4Expr(gParser.BinaryOp4ExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code funcCallExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFuncCallExpr(gParser.FuncCallExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code funcCallExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFuncCallExpr(gParser.FuncCallExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryOpExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOpExpr(gParser.UnaryOpExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryOpExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOpExpr(gParser.UnaryOpExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code varExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVarExpr(gParser.VarExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code varExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVarExpr(gParser.VarExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code bitwiseOpExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBitwiseOpExpr(gParser.BitwiseOpExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code bitwiseOpExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBitwiseOpExpr(gParser.BitwiseOpExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code binaryOp2Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBinaryOp2Expr(gParser.BinaryOp2ExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code binaryOp2Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBinaryOp2Expr(gParser.BinaryOp2ExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code nilEpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNilEpr(gParser.NilEprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code nilEpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNilEpr(gParser.NilEprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code constvalExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConstvalExpr(gParser.ConstvalExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code constvalExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConstvalExpr(gParser.ConstvalExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code listExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterListExpr(gParser.ListExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code listExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitListExpr(gParser.ListExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#func_call}.
	 * @param ctx the parse tree
	 */
	void enterFunc_call(gParser.Func_callContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#func_call}.
	 * @param ctx the parse tree
	 */
	void exitFunc_call(gParser.Func_callContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#list}.
	 * @param ctx the parse tree
	 */
	void enterList(gParser.ListContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#list}.
	 * @param ctx the parse tree
	 */
	void exitList(gParser.ListContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#handle_call}.
	 * @param ctx the parse tree
	 */
	void enterHandle_call(gParser.Handle_callContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#handle_call}.
	 * @param ctx the parse tree
	 */
	void exitHandle_call(gParser.Handle_callContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#params}.
	 * @param ctx the parse tree
	 */
	void enterParams(gParser.ParamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#params}.
	 * @param ctx the parse tree
	 */
	void exitParams(gParser.ParamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#cond_stmt}.
	 * @param ctx the parse tree
	 */
	void enterCond_stmt(gParser.Cond_stmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#cond_stmt}.
	 * @param ctx the parse tree
	 */
	void exitCond_stmt(gParser.Cond_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#switch_body}.
	 * @param ctx the parse tree
	 */
	void enterSwitch_body(gParser.Switch_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#switch_body}.
	 * @param ctx the parse tree
	 */
	void exitSwitch_body(gParser.Switch_bodyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code for_stmt}
	 * labeled alternative in {@link gParser#loop_stmt}.
	 * @param ctx the parse tree
	 */
	void enterFor_stmt(gParser.For_stmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code for_stmt}
	 * labeled alternative in {@link gParser#loop_stmt}.
	 * @param ctx the parse tree
	 */
	void exitFor_stmt(gParser.For_stmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code while_stmt}
	 * labeled alternative in {@link gParser#loop_stmt}.
	 * @param ctx the parse tree
	 */
	void enterWhile_stmt(gParser.While_stmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code while_stmt}
	 * labeled alternative in {@link gParser#loop_stmt}.
	 * @param ctx the parse tree
	 */
	void exitWhile_stmt(gParser.While_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(gParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(gParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#const_val}.
	 * @param ctx the parse tree
	 */
	void enterConst_val(gParser.Const_valContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#const_val}.
	 * @param ctx the parse tree
	 */
	void exitConst_val(gParser.Const_valContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#unary_op}.
	 * @param ctx the parse tree
	 */
	void enterUnary_op(gParser.Unary_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#unary_op}.
	 * @param ctx the parse tree
	 */
	void exitUnary_op(gParser.Unary_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#op1}.
	 * @param ctx the parse tree
	 */
	void enterOp1(gParser.Op1Context ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#op1}.
	 * @param ctx the parse tree
	 */
	void exitOp1(gParser.Op1Context ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#op2}.
	 * @param ctx the parse tree
	 */
	void enterOp2(gParser.Op2Context ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#op2}.
	 * @param ctx the parse tree
	 */
	void exitOp2(gParser.Op2Context ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#op3}.
	 * @param ctx the parse tree
	 */
	void enterOp3(gParser.Op3Context ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#op3}.
	 * @param ctx the parse tree
	 */
	void exitOp3(gParser.Op3Context ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#op4}.
	 * @param ctx the parse tree
	 */
	void enterOp4(gParser.Op4Context ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#op4}.
	 * @param ctx the parse tree
	 */
	void exitOp4(gParser.Op4Context ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#bitwise}.
	 * @param ctx the parse tree
	 */
	void enterBitwise(gParser.BitwiseContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#bitwise}.
	 * @param ctx the parse tree
	 */
	void exitBitwise(gParser.BitwiseContext ctx);
	/**
	 * Enter a parse tree produced by {@link gParser#logical}.
	 * @param ctx the parse tree
	 */
	void enterLogical(gParser.LogicalContext ctx);
	/**
	 * Exit a parse tree produced by {@link gParser#logical}.
	 * @param ctx the parse tree
	 */
	void exitLogical(gParser.LogicalContext ctx);
}