package lulu;// Generated from C:/Users/Mohammad Hossein/IdeaProjects/compiler_project\g.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link gParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface gVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link gParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(gParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#test}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTest(gParser.TestContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#ft_dcl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFt_dcl(gParser.Ft_dclContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#func_dcl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunc_dcl(gParser.Func_dclContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#args}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgs(gParser.ArgsContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#args_var}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgs_var(gParser.Args_varContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#type_dcl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_dcl(gParser.Type_dclContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#var_def}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVar_def(gParser.Var_defContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#var_val}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVar_val(gParser.Var_valContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#ft_def}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFt_def(gParser.Ft_defContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#type_def}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_def(gParser.Type_defContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#component}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComponent(gParser.ComponentContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#access_modifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAccess_modifier(gParser.Access_modifierContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#fun_def}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFun_def(gParser.Fun_defContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(gParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignstmt(gParser.AssignstmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code funcCallstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncCallstmt(gParser.FuncCallstmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code condstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCondstmt(gParser.CondstmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code loopstmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLoopstmt(gParser.LoopstmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code breakstmr}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBreakstmr(gParser.BreakstmrContext ctx);
	/**
	 * Visit a parse tree produced by the {@code continuestmt}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContinuestmt(gParser.ContinuestmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code destructstmr}
	 * labeled alternative in {@link gParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDestructstmr(gParser.DestructstmrContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#assign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign(gParser.AssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#var}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVar(gParser.VarContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#ref}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRef(gParser.RefContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryOp1Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOp1Expr(gParser.BinaryOp1ExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code allocHandleCallExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAllocHandleCallExpr(gParser.AllocHandleCallExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryOp3Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOp3Expr(gParser.BinaryOp3ExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code logicalExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalExpr(gParser.LogicalExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code nestedExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNestedExpr(gParser.NestedExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryOp4Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOp4Expr(gParser.BinaryOp4ExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code funcCallExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncCallExpr(gParser.FuncCallExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryOpExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryOpExpr(gParser.UnaryOpExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code varExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarExpr(gParser.VarExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code bitwiseOpExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBitwiseOpExpr(gParser.BitwiseOpExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryOp2Expr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOp2Expr(gParser.BinaryOp2ExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code nilEpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNilEpr(gParser.NilEprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code constvalExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstvalExpr(gParser.ConstvalExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code listExpr}
	 * labeled alternative in {@link gParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListExpr(gParser.ListExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#func_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunc_call(gParser.Func_callContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList(gParser.ListContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#handle_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHandle_call(gParser.Handle_callContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#params}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParams(gParser.ParamsContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#cond_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCond_stmt(gParser.Cond_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#switch_body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSwitch_body(gParser.Switch_bodyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code for_stmt}
	 * labeled alternative in {@link gParser#loop_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor_stmt(gParser.For_stmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code while_stmt}
	 * labeled alternative in {@link gParser#loop_stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhile_stmt(gParser.While_stmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType(gParser.TypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#const_val}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConst_val(gParser.Const_valContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#unary_op}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnary_op(gParser.Unary_opContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#op1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOp1(gParser.Op1Context ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#op2}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOp2(gParser.Op2Context ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#op3}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOp3(gParser.Op3Context ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#op4}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOp4(gParser.Op4Context ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#bitwise}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBitwise(gParser.BitwiseContext ctx);
	/**
	 * Visit a parse tree produced by {@link gParser#logical}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogical(gParser.LogicalContext ctx);
}