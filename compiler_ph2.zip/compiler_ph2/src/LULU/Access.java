package lulu;
public enum Access
{
    PRIVATE , PUBLIC , PROTECTED;
}