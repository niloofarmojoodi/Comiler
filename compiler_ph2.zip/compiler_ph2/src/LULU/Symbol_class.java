package LULU;

import java.util.LinkedList;

public class Symbol_class extends Symbol_tot {
    LinkedList<Symbol_tot> listContainClass = new LinkedList();
    private Symbol_class parentclass ;

    public void setParentclass(Symbol_class parentclass) {
        this.parentclass = parentclass;
    }

    public Symbol_class getParentclass() {
        return parentclass;
    }
}
