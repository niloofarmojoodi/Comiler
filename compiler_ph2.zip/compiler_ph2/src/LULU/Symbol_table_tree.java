package lulu;


import java.util.LinkedList;

public class Symbol_table_tree {
    private Scope root;
    private Scope currentScope;

    public Symbol_table_tree(String name , LinkedList data){
        this.root = new Scope(name ,data, null);
        this.currentScope = root;

    }

    public void setCurrentScope(Scope currentScope) {
        this.currentScope = currentScope;
    }

    public Scope getCurrentScope() {
        return currentScope;
    }

    public void setRoot(Scope root) {
        this.root = root;
    }
    public Scope getRoot() { return root; }

   /* public void writeTree(Scope scope )
    {
        for(int i=0; i<(scope.getData().size()); i++) {
            if (scope.getData().get(i) != null) {
                System.out.print("a scope is" + '\n');
                System.out.print("Name Of Symbol is" + '\t' + scope.getData().get(i).getName() + '\t');
                System.out.print("widt of Symbol is" + '\t' + scope.getData().get(i).getWidth() + '\t');
                System.out.print("Type of Symbol is" + '\t' + scope.getData().get(i).getType() + '\t' + '\n');
                //   System.out.print("address of Symbol is" + '\t' + node.getData().get(i).getAddress() + '\t' + '\n');


            }
        }
        for(Scope n: scope.getChildren()) {
            writeTree(n); }
    }*/

}

