package LULU;

import java.util.ArrayList;
import java.util.LinkedList;

public class Symbol_function extends Symbol_tot {
    private ArrayList<Boolean> return_value_check;//return value ha ro meghdar dehi karde ya na
    private ArrayList<String> return_type;//chi return karde (typesh bokhore ya na)
    private ArrayList<Object> Argument_value;
    LinkedList<Symbol_tot> listContainfunction = new LinkedList<>();


    public void setReturn_type(ArrayList<String> return_type) {
        this.return_type = return_type;
    }

    public void setReturn_value_check(ArrayList<Boolean> return_value) {
        this.return_value_check = return_value;
    }

    public void setArgument_value(ArrayList<Object> argument_value) {
        Argument_value = argument_value;
    }

    public ArrayList<String> getReturn_type() {
        return return_type;
    }
    public ArrayList getArgument_value() {
        return Argument_value;
    }
    public ArrayList getReturn_value_check() {
        return return_value_check;
    }
}
