package lulu;

import java.util.ArrayList;

public class Symbol_id extends Symbol_tot {
    private boolean isconstant ;
    private int dimentional ; //bode araye
    private ArrayList<Integer> Array_width;
    private boolean is_Array;
    private Object value;


    public void setValue(Object value) {
        this.value = value;
    }

    public void setAcces(Access acces) {
        super.setAcces(acces);
    }
    public void setIs_Array(boolean is_array){
        this.is_Array = is_array;
    }

    public void setIsconstant(boolean isconstant) {
        this.isconstant = isconstant;
    }

    public void setDimentional(int dimentional) {
        this.dimentional = dimentional;
    }


    public void setArray_width(ArrayList<Integer> array_width) {
        this.Array_width = array_width;
        for (int i=0;i<this.dimentional;i++){
            this.Array_width.add(0);
        }
    }

    public void setWidth(Type tp)
    {
        if(tp.toString().equals("int")){
            super.setWidth(4);
        }
        if(tp.toString().equals("bool")){
            super.setWidth(4);
        }
        if(tp.toString().equals("string") ){
            int l = this.value.toString().length();
            super.setWidth(2 * l + 2);
        }
        //Array checking
        if(is_Array){
            if(tp.toString().equals("int")){
                int multi=1;

                for (int i=0;i<this.dimentional;i++){

                    multi *= this.Array_width.get(i) ;
                }
                super.setWidth(4 * multi);

            }
            if(tp.toString().equals("float")){
                int multi=1;

                for (int i=0;i<this.dimentional;i++){

                    multi *= this.Array_width.get(i) ;
                }
                super.setWidth(8 * multi);
            }
            if(tp.toString().equals("bool")){
                int multi=1;

                for (int i=0;i<this.dimentional;i++){

                    multi *= this.Array_width.get(i) ;
                }
                super.setWidth(multi);
            }

        }


    }

    public boolean getIs_Array(){
        return is_Array;
    }
    public Object getValue() {
        return value;
    }

    public int getDimentional() {
        return dimentional;
    }

    public ArrayList<Integer> getArray_width() {
        return Array_width;
    }

    public boolean getIsconstant(){
        return isconstant;
    }

}
