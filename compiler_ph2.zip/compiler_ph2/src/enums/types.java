package enums;

public enum types{
    t_int , t_float,t_bool,t_string;
}