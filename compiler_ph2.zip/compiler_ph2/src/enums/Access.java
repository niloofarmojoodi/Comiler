package enums;

public enum Access {
    PUBLIC,PRIVATE,PROTECTED;
}