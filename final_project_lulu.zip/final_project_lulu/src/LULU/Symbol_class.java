package LULU;

import java.util.LinkedList;

public class Symbol_class {
    private  int width;
    private  int offset;
    private String name;
    private Access access;
    private Symbol_class parentClass = null ;

    public String getName() {
        return name;
    }

    public Access getAccess() {
        return access;
    }

    public int getOffset() {
        return offset;
    }

    public int getWidth() {
        return width;
    }


    public void setAccess(Access access) {
        this.access = access;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setParentClass(Symbol_class parentClass) {
        this.parentClass = parentClass;
    }

    public Symbol_class getParentClass() {
        return parentClass;
    }
}
