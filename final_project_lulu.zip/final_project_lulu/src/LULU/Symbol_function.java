package LULU;

import java.util.ArrayList;
import java.util.LinkedList;

public class Symbol_function {
    private  int width;
    private  int offset;
    private String type;
    private String name;
    private Access access;

    private ArrayList<Boolean> return_value_check; //return value ha ro meghdar dehi karde ya na
    private ArrayList<String> return_type;//chi return karde (typesh bokhore ya na)
    private ArrayList<String> Argument_type;

    public String currentFunction ;


    public void setReturn_value_check(ArrayList<Boolean> return_value) {
        this.return_value_check = return_value;
    }

    public void setArgument_type(ArrayList<String> argument_type) {
        Argument_type = argument_type;
    }

    public void setReturn_type(ArrayList<String> return_type) {
        this.return_type = return_type;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAccess(Access access) {
        this.access = access;
    }

    public void setCurrentFunction(String currentFunction) {
        this.currentFunction = currentFunction;
    }

    public String getType() {
        return type;
    }

    public int getWidth() {
        return width;
    }

    public int getOffset() {
        return offset;
    }

    public Access getAccess() {
        return access;
    }

    public String getName() {
        return name;
    }

    public String getCurrentFunction() {
        return currentFunction;
    }


    public ArrayList<String> getReturn_type() {
        return return_type;
    }
    public ArrayList<String> getArgument_type() {
        return Argument_type;
    }
    public ArrayList<Boolean> getReturn_value_check() {
        return return_value_check;
    }
}
