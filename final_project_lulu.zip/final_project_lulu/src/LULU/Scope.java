package LULU;
import java.util.LinkedList;

public class Scope {
    private String Name;
    private Symbol_tot DataTable;
    private Scope Parent;
    private LinkedList<Scope> Children = new LinkedList<>();;
   // private int width;

    public Scope(String Name){
        this.Name = Name;
        this.DataTable = new Symbol_tot();
    }

    public String getName() {
        return Name;
    }

    public Scope addChildren(String name)
    {
        Scope child = new Scope(name);
        child.setParent(this);
        this.Children.add(child);
        return child;

    }

    public void setDataTable(Symbol_tot dataTable) {
        DataTable = dataTable;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setChildren(LinkedList<Scope> children) {
        Children = children;
    }

    public void setParent(Scope parent) {
        Parent = parent;
    }

    public Symbol_tot getDataTable() {
        return DataTable;
    }

    public Scope getParent() {
        return Parent;
    }

    public LinkedList<Scope> getChildren() {
        return Children;
    }

    public Scope insert_child(String name , LinkedList data ){
        Scope child = new Scope(name);
        this.Children.addLast(child);
        return child;
    }

   /* public int calcWidth() {
        int width = 0;
        if(this.Children.size() == 0)
        {
            width = this.Table.calc_width();
        }
        else
        {
            for(int i=0;i<this.Children.size();i++){
                width += this.Children.get(i).calcWidth();
            }
            width += this.Table.calc_width();
        }

        return width;

    }*/



}
