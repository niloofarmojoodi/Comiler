package LULU;

import java.util.ArrayList;

public class Symbol_id {
    private  int width;
    private  int offset;
    private String type;
    private String name;
    private Access access;

    private boolean isconstant ;
    private int dimentional ; //bode araye
    private ArrayList<Integer> Array_width;
    private boolean is_Array;
    private Object value;



    public boolean getIs_Array()
    {
        return is_Array;
    }
    public Object getValue() {
        return value;
    }

    public int getDimentional() {
        return dimentional;
    }

    public ArrayList<Integer> getArray_width() {
        return Array_width;
    }

    public boolean getIsconstant(){
        return isconstant;
    }

    public String getName() {
        return name;
    }

    public Access getAccess() {
        return access;
    }

    public int getOffset() {
        return offset;
    }

    public int getWidth() {
        return width;
    }

    public String getType() {
        return type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setWidth(int width) {
        this.width = width;
    }


    public void setValue(Object value) {
        this.value = value;
    }

    public void setAccess(Access access) {
        this.access = access;
    }
    public void setIs_Array(boolean is_array)
    {
        this.is_Array = is_array;
    }

    public void setIsconstant(boolean isconstant)
    {
        this.isconstant = isconstant;
    }

    public void setDimentional(int dimentional)
    {
        this.dimentional = dimentional;
    }


    public void setArray_width(ArrayList<Integer> array_width) {
        this.Array_width = array_width;
        for (int i=0;i<this.dimentional;i++){
            this.Array_width.add(0);
        }
    }

    public void calculate_width(String tp)
    {
        if(tp.equals("int")){
            setWidth(4);
        }
        if(tp.equals("bool")){
            setWidth(4);
        }
        if(tp.equals("string") ){
            int l = this.value.toString().length();
            setWidth(2 * l + 2);
        }
        //Array checking
        if(is_Array){
            if(tp.equals("int")){
                int multi=1;

                for (int i=0;i<this.dimentional;i++){

                    multi *= this.Array_width.get(i) ;
                }
                setWidth(4 * multi);

            }
            if(tp.toString().equals("float")){
                int multi=1;

                for (int i=0;i<this.dimentional;i++){

                    multi *= this.Array_width.get(i) ;
                }
                this.setWidth(8 * multi);
            }
            if(tp.toString().equals("bool")){
                int multi=1;

                for (int i=0;i<this.dimentional;i++){

                    multi *= this.Array_width.get(i) ;
                }
                this.setWidth(multi);
            }

        }

    }



}
