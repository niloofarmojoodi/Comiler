package LULU;// Generated from C:/Users/Niloofar Mojoodi/IdeaProjects/final_project_lulu/src\lulu.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link luluParser}.
 */
public interface luluListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link luluParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(luluParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(luluParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#ft_dcl}.
	 * @param ctx the parse tree
	 */
	void enterFt_dcl(luluParser.Ft_dclContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#ft_dcl}.
	 * @param ctx the parse tree
	 */
	void exitFt_dcl(luluParser.Ft_dclContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#func_dcl}.
	 * @param ctx the parse tree
	 */
	void enterFunc_dcl(luluParser.Func_dclContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#func_dcl}.
	 * @param ctx the parse tree
	 */
	void exitFunc_dcl(luluParser.Func_dclContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#args}.
	 * @param ctx the parse tree
	 */
	void enterArgs(luluParser.ArgsContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#args}.
	 * @param ctx the parse tree
	 */
	void exitArgs(luluParser.ArgsContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#args_var}.
	 * @param ctx the parse tree
	 */
	void enterArgs_var(luluParser.Args_varContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#args_var}.
	 * @param ctx the parse tree
	 */
	void exitArgs_var(luluParser.Args_varContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#type_dcl}.
	 * @param ctx the parse tree
	 */
	void enterType_dcl(luluParser.Type_dclContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#type_dcl}.
	 * @param ctx the parse tree
	 */
	void exitType_dcl(luluParser.Type_dclContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#var_def}.
	 * @param ctx the parse tree
	 */
	void enterVar_def(luluParser.Var_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#var_def}.
	 * @param ctx the parse tree
	 */
	void exitVar_def(luluParser.Var_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#var_val}.
	 * @param ctx the parse tree
	 */
	void enterVar_val(luluParser.Var_valContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#var_val}.
	 * @param ctx the parse tree
	 */
	void exitVar_val(luluParser.Var_valContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#ft_def}.
	 * @param ctx the parse tree
	 */
	void enterFt_def(luluParser.Ft_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#ft_def}.
	 * @param ctx the parse tree
	 */
	void exitFt_def(luluParser.Ft_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#type_def}.
	 * @param ctx the parse tree
	 */
	void enterType_def(luluParser.Type_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#type_def}.
	 * @param ctx the parse tree
	 */
	void exitType_def(luluParser.Type_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#component}.
	 * @param ctx the parse tree
	 */
	void enterComponent(luluParser.ComponentContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#component}.
	 * @param ctx the parse tree
	 */
	void exitComponent(luluParser.ComponentContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#access_modifier}.
	 * @param ctx the parse tree
	 */
	void enterAccess_modifier(luluParser.Access_modifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#access_modifier}.
	 * @param ctx the parse tree
	 */
	void exitAccess_modifier(luluParser.Access_modifierContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#fun_def}.
	 * @param ctx the parse tree
	 */
	void enterFun_def(luluParser.Fun_defContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#fun_def}.
	 * @param ctx the parse tree
	 */
	void exitFun_def(luluParser.Fun_defContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(luluParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(luluParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code assignment}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(luluParser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code assignment}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(luluParser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code function_call}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterFunction_call(luluParser.Function_callContext ctx);
	/**
	 * Exit a parse tree produced by the {@code function_call}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitFunction_call(luluParser.Function_callContext ctx);
	/**
	 * Enter a parse tree produced by the {@code conditional_statement}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterConditional_statement(luluParser.Conditional_statementContext ctx);
	/**
	 * Exit a parse tree produced by the {@code conditional_statement}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitConditional_statement(luluParser.Conditional_statementContext ctx);
	/**
	 * Enter a parse tree produced by the {@code loop_statement}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterLoop_statement(luluParser.Loop_statementContext ctx);
	/**
	 * Exit a parse tree produced by the {@code loop_statement}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitLoop_statement(luluParser.Loop_statementContext ctx);
	/**
	 * Enter a parse tree produced by the {@code break}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterBreak(luluParser.BreakContext ctx);
	/**
	 * Exit a parse tree produced by the {@code break}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitBreak(luluParser.BreakContext ctx);
	/**
	 * Enter a parse tree produced by the {@code continue}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterContinue(luluParser.ContinueContext ctx);
	/**
	 * Exit a parse tree produced by the {@code continue}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitContinue(luluParser.ContinueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code destruction}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterDestruction(luluParser.DestructionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code destruction}
	 * labeled alternative in {@link luluParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitDestruction(luluParser.DestructionContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterAssign(luluParser.AssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitAssign(luluParser.AssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#var}.
	 * @param ctx the parse tree
	 */
	void enterVar(luluParser.VarContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#var}.
	 * @param ctx the parse tree
	 */
	void exitVar(luluParser.VarContext ctx);
	/**
	 * Enter a parse tree produced by the {@code reef}
	 * labeled alternative in {@link luluParser#ref}.
	 * @param ctx the parse tree
	 */
	void enterReef(luluParser.ReefContext ctx);
	/**
	 * Exit a parse tree produced by the {@code reef}
	 * labeled alternative in {@link luluParser#ref}.
	 * @param ctx the parse tree
	 */
	void exitReef(luluParser.ReefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code varLabel}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVarLabel(luluParser.VarLabelContext ctx);
	/**
	 * Exit a parse tree produced by the {@code varLabel}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVarLabel(luluParser.VarLabelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opBitwise}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpBitwise(luluParser.OpBitwiseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opBitwise}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpBitwise(luluParser.OpBitwiseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code listLabel}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterListLabel(luluParser.ListLabelContext ctx);
	/**
	 * Exit a parse tree produced by the {@code listLabel}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitListLabel(luluParser.ListLabelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opLogical}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpLogical(luluParser.OpLogicalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opLogical}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpLogical(luluParser.OpLogicalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code handleCall}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterHandleCall(luluParser.HandleCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code handleCall}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitHandleCall(luluParser.HandleCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOp(luluParser.UnaryOpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryOp}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOp(luluParser.UnaryOpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code paranthese}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterParanthese(luluParser.ParantheseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code paranthese}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitParanthese(luluParser.ParantheseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opFour}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpFour(luluParser.OpFourContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opFour}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpFour(luluParser.OpFourContext ctx);
	/**
	 * Enter a parse tree produced by the {@code nilLabel}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNilLabel(luluParser.NilLabelContext ctx);
	/**
	 * Exit a parse tree produced by the {@code nilLabel}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNilLabel(luluParser.NilLabelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opOne}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpOne(luluParser.OpOneContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opOne}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpOne(luluParser.OpOneContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arrayVal}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArrayVal(luluParser.ArrayValContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arrayVal}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArrayVal(luluParser.ArrayValContext ctx);
	/**
	 * Enter a parse tree produced by the {@code funcCall}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFuncCall(luluParser.FuncCallContext ctx);
	/**
	 * Exit a parse tree produced by the {@code funcCall}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFuncCall(luluParser.FuncCallContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opTwo}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpTwo(luluParser.OpTwoContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opTwo}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpTwo(luluParser.OpTwoContext ctx);
	/**
	 * Enter a parse tree produced by the {@code opThree}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOpThree(luluParser.OpThreeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code opThree}
	 * labeled alternative in {@link luluParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOpThree(luluParser.OpThreeContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#func_call}.
	 * @param ctx the parse tree
	 */
	void enterFunc_call(luluParser.Func_callContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#func_call}.
	 * @param ctx the parse tree
	 */
	void exitFunc_call(luluParser.Func_callContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#list}.
	 * @param ctx the parse tree
	 */
	void enterList(luluParser.ListContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#list}.
	 * @param ctx the parse tree
	 */
	void exitList(luluParser.ListContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#handle_call}.
	 * @param ctx the parse tree
	 */
	void enterHandle_call(luluParser.Handle_callContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#handle_call}.
	 * @param ctx the parse tree
	 */
	void exitHandle_call(luluParser.Handle_callContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#params}.
	 * @param ctx the parse tree
	 */
	void enterParams(luluParser.ParamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#params}.
	 * @param ctx the parse tree
	 */
	void exitParams(luluParser.ParamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#cond_stmt}.
	 * @param ctx the parse tree
	 */
	void enterCond_stmt(luluParser.Cond_stmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#cond_stmt}.
	 * @param ctx the parse tree
	 */
	void exitCond_stmt(luluParser.Cond_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#switch_body}.
	 * @param ctx the parse tree
	 */
	void enterSwitch_body(luluParser.Switch_bodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#switch_body}.
	 * @param ctx the parse tree
	 */
	void exitSwitch_body(luluParser.Switch_bodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#loop_stmt}.
	 * @param ctx the parse tree
	 */
	void enterLoop_stmt(luluParser.Loop_stmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#loop_stmt}.
	 * @param ctx the parse tree
	 */
	void exitLoop_stmt(luluParser.Loop_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(luluParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(luluParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#const_val}.
	 * @param ctx the parse tree
	 */
	void enterConst_val(luluParser.Const_valContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#const_val}.
	 * @param ctx the parse tree
	 */
	void exitConst_val(luluParser.Const_valContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#unary_op}.
	 * @param ctx the parse tree
	 */
	void enterUnary_op(luluParser.Unary_opContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#unary_op}.
	 * @param ctx the parse tree
	 */
	void exitUnary_op(luluParser.Unary_opContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#op1}.
	 * @param ctx the parse tree
	 */
	void enterOp1(luluParser.Op1Context ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#op1}.
	 * @param ctx the parse tree
	 */
	void exitOp1(luluParser.Op1Context ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#op2}.
	 * @param ctx the parse tree
	 */
	void enterOp2(luluParser.Op2Context ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#op2}.
	 * @param ctx the parse tree
	 */
	void exitOp2(luluParser.Op2Context ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#op3}.
	 * @param ctx the parse tree
	 */
	void enterOp3(luluParser.Op3Context ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#op3}.
	 * @param ctx the parse tree
	 */
	void exitOp3(luluParser.Op3Context ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#op4}.
	 * @param ctx the parse tree
	 */
	void enterOp4(luluParser.Op4Context ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#op4}.
	 * @param ctx the parse tree
	 */
	void exitOp4(luluParser.Op4Context ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#bitwise}.
	 * @param ctx the parse tree
	 */
	void enterBitwise(luluParser.BitwiseContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#bitwise}.
	 * @param ctx the parse tree
	 */
	void exitBitwise(luluParser.BitwiseContext ctx);
	/**
	 * Enter a parse tree produced by {@link luluParser#logical}.
	 * @param ctx the parse tree
	 */
	void enterLogical(luluParser.LogicalContext ctx);
	/**
	 * Exit a parse tree produced by {@link luluParser#logical}.
	 * @param ctx the parse tree
	 */
	void exitLogical(luluParser.LogicalContext ctx);
}