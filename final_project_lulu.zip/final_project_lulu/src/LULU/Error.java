package LULU;

public class Error {

    public Error(int line , int position , String text){
        System.out.println("in line : " + line + " in position: " + position + " found error : " + text);
    }
}
